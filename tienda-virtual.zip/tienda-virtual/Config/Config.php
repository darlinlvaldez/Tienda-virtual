<?php
const BASE_URL = "http://localhost/tienda-virtual/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda_virtual";
const CHARSET = "charset=utf8";
const TITLE = "LA MODA";
const MONEDA = "USD";
const CLIENT_ID = "";
const USER_SMTP = "darlinlvaldez@gmail.com";
const PASS_SMTP = "awyyxxhttwkmefrl";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";
?>