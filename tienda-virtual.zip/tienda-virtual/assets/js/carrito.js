const btnAddcarrito = document.querySelectorAll(".btnAddcarrito");
const btnCarrito = document.querySelector("#btnCantidadCarrito");
const tableListaCarrito = document.querySelector("#tableListaCarrito tbody");
const verCarrito = document.querySelector('#verCarrito');
let listaCarrito;

document.addEventListener('DOMContentLoaded', function() {
    if (localStorage.getItem('listaCarrito') != null) {
        listaCarrito = JSON.parse(localStorage.getItem('listaCarrito'));
    } else {
        listaCarrito = [];
    }

    for (let i = 0; i < btnAddcarrito.length; i++) {
        btnAddcarrito[i].addEventListener("click", function() {
            let idProducto = btnAddcarrito[i].getAttribute("prod"); 
            agregarCarrito(idProducto, 1);
        });
    }
    cantidadCarrito();

    // Ver carrito
    if (verCarrito) {
        const myModal = new bootstrap.Modal(document.getElementById("myModal"));
        verCarrito.addEventListener('click', function(){
            getListaCarrito();
            myModal.show();
        });
    }
});

// Agregar productos al carrito
function agregarCarrito(idProducto, cantidad) {
    let productoExistente = false;

    if (localStorage.getItem("listaCarrito") == null) {
        listaCarrito = [];
    } else {
        listaCarrito = JSON.parse(localStorage.getItem("listaCarrito"));
        
        for (let i = 0; i < listaCarrito.length; i++) {
            if (listaCarrito[i]["idProducto"] == idProducto) {
                Swal.fire("¡Aviso!", "EL PRODUCTO YA ESTÁ AGREGADO", "warning");
                productoExistente = true;
                return;
            }
        }
    }

    if (!productoExistente) {
        listaCarrito.push({
            idProducto: idProducto, 
            cantidad: cantidad,
        });
        Swal.fire("¡Aviso!", "PRODUCTO AGREGADO AL CARRITO", "success");
    }

    localStorage.setItem("listaCarrito", JSON.stringify(listaCarrito));
    cantidadCarrito();
}

function cantidadCarrito() {
    let listas = JSON.parse(localStorage.getItem("listaCarrito"));
    if (listas != null) {
        btnCarrito.textContent = listas.length;
    } else {
        btnCarrito.textContent = 0;
    }
}

function getListaCarrito() {
    const url = base_url + 'principal/listaProductos'; 
    const http = new XMLHttpRequest(); 
    http.open('POST', url, true); 
    http.setRequestHeader('Content-Type', 'application/json'); 
    http.send(JSON.stringify(listaCarrito));
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) { 
            const res = JSON.parse(this.responseText);
            let html = '';
            res.productos.forEach(producto => {
                html += `<tr>
                <td><img class="img-thumbnail rounded-squares" src="${producto.imagen}"/>
                </td>
                <td>${producto.nombre}</td>
                <td><span class="badge bg-success">${res.moneda + ' ' + producto.precio}</span></td>
                <td><span class="badge bg-success">${producto.cantidad}</span></td>
                <td>${producto.subTotal}</td>
                <td>
                <button class="btn btn-danger btnDeletecart" type="button" prod="${producto.id}"><i class="fas fa-times-circle"></i></button>
                </tr>`;
            });
            tableListaCarrito.innerHTML = html;         
            document.querySelector('#totalGeneral').textContent = res.total;
            btnEliminarCarrito();
        }
    }
}

function btnEliminarCarrito() {
    let listaEliminar = document.querySelectorAll('.btnDeletecart'); 
    for (let i = 0; i < listaEliminar.length; i++) {
        listaEliminar[i].addEventListener('click', function () {
            let idProducto = listaEliminar[i].getAttribute('prod');
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡Tendrás que buscarlo de nuevo!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    eliminarListaCarrito(idProducto);
                }
            });
        })
    }
}

function eliminarListaCarrito(idProducto) {
    for (let i = 0; i < listaCarrito.length; i++) {
        if (listaCarrito[i]['idProducto'] == idProducto) {
            listaCarrito.splice(i, 1);
            break; // Salir del bucle una vez que se ha eliminado el producto
        }
    }
    localStorage.setItem('listaCarrito', JSON.stringify(listaCarrito));
    getListaCarrito();
    cantidadCarrito();
    Swal.fire(
        '¡Eliminado!',
        'El producto ha sido eliminado del carrito.',
        'success'
    );
}
