<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

class Clientes extends Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }

    public function index()
    {
        if (empty($_SESSION['correo'])) {
            header('Location: ' . BASE_URL . 'login');
            exit();
        }

        $data['title'] = 'Tu Perfil';
        $data['verificar'] = $this->model->getVerificar($_SESSION['correo']);
        $this->views->getView('principal', 'perfil', $data);
    }

    public function registroDirecto()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (isset($_POST['nombre']) && isset($_POST['correo']) && isset($_POST['clave'])) {
                $nombre = $_POST['nombre'];
                $correo = $_POST['correo'];
                $clave = $_POST['clave'];

                // Validar campos vacíos
                if (empty($nombre) || empty($correo) || empty($clave)) {
                    $mensaje = array('msg' => 'TODOS LOS CAMPOS SON REQUERIDOS', 'icono' => 'warning');
                } else {
                    $verificar = $this->model->getVerificar($correo);

                    if (empty($verificar)) {
                        $token = md5($correo);
                        $hash = password_hash($clave, PASSWORD_DEFAULT);
                        $data = $this->model->registroDirecto($nombre, $correo, $hash, $token);

                        if ($data > 0) {
                            $_SESSION['correo'] = $correo;
                            $_SESSION['nombre'] = $nombre;
                            $envioCorreo = $this->enviarCorreo($correo, $token);
                            if ($envioCorreo === true) {
                                $mensaje = array('msg' => 'Registrado con éxito y correo enviado', 'icono' => 'success');
                            } else {
                                $mensaje = array('msg' => 'Registrado con éxito, pero error al enviar el correo: ' . $envioCorreo, 'icono' => 'warning');
                            }
                        } else {
                            $mensaje = array('msg' => 'Error al registrarse', 'icono' => 'error');
                        }
                    } else {
                        $mensaje = array('msg' => 'YA TIENES UNA CUENTA', 'icono' => 'warning');
                    }
                }
            } else {
                $mensaje = array('msg' => 'Todos los campos son requeridos', 'icono' => 'warning');
            }

            echo json_encode($mensaje, JSON_UNESCAPED_UNICODE);
            exit();
        }
    }

    function enviarCorreo($correo, $token)
    {
        $mail = new PHPMailer(true);

        try {
            // Configuración del servidor
            $mail->SMTPDebug = 0;                    // Desactivar salida de depuración detallada
            $mail->isSMTP();                         // Usar SMTP
            $mail->Host       = HOST_SMTP;           // Servidor SMTP
            $mail->SMTPAuth   = true;                // Habilitar autenticación SMTP
            $mail->Username   = USER_SMTP;           // Usuario SMTP
            $mail->Password   = PASS_SMTP;           // Contraseña SMTP
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Encriptación TLS implícita
            $mail->Port       = PUERTO_SMTP;         // Puerto TCP para conectarse

            // Destinatarios
            $mail->setFrom('darlinlvaldez@gmail.com', TITLE);
            $mail->addAddress($correo);     // Añadir destinatario

            // Contenido
            $mail->isHTML(true);                                  // Establecer formato de correo a HTML
            $mail->Subject = 'Mensaje desde la ' . TITLE;
            $mail->Body    = 'Para verificar tu correo <a href="' . BASE_URL . 'clientes/verificarCorreo/' . $token . '">CLICK AQUÍ</a>';
            $mail->AltBody = 'Gracias por la preferencia';

            $mail->send();
            return true;
        } catch (Exception $e) {
            return "Error AL ENVIAR CORREO: {$mail->ErrorInfo}";
        }
    }

    public function verificarCorreo($token)
    {
        $verificar = $this->model->getToken($token);
        if (!empty($verificar)) {
            $data = $this->model->actualizarVerify($verificar['id']);
            header('Location: ' . BASE_URL . 'clientes');
            exit();
        } else {
            // Token inválido o no encontrado
            echo "Token inválido o no encontrado.";
        }
    }
}
